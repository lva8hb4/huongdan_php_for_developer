<?php
require 'vendor/autoload.php';
use Dotenv\Dotenv;
use Src\Database;
//Xử lý load thư viện và kết nối đến db
$dotenv = Dotenv::createImmutable(__DIR__);
$dotenv->load();

//In thông tin host
//echo $_ENV['DB_HOST'];
$dbConnection = (new Database())->connet();