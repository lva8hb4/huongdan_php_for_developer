<?php
require "../start.php";
use Src\ChuDe;
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: OPTIONS,GET,POST,PUT,DELETE");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$uri = explode('/', $uri);
//print_r($uri);
// all of our endpoints start with /chude or /chudes
// everything else results in a 404 Not Found
if ($uri[1] !== 'chude') {

    if ($uri[1] !== 'chudes') {
        header("HTTP/1.1 404 Not Found");
        exit();
    }
}

if ($uri[1] == 'chudes' and isset($uri[2])) {
    header("HTTP/1.1 404 Not Found");
    exit();
}

// the post id is, of course, optional and must be a number:
$ma = null;
if (isset($uri[2])) {
    $ma = $uri[2];
}

$requestMethod = $_SERVER["REQUEST_METHOD"];
//pass the request method and ID to the Post and process the HTTP request:
$controller = new ChuDe($dbConnection, $requestMethod, $ma);
$controller->processRequest();