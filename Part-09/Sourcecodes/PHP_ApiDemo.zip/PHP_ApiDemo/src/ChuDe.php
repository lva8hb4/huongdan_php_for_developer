<?php


namespace Src;


class ChuDe
{
    private $db;
    private $requestMethod;
    private $ma;
    public function __construct($db, $requestMethod, $ma)
    {
        $this->db = $db;
        $this->requestMethod = $requestMethod;
        $this->ma = $ma;
    }

    public function processRequest()
    {
        switch ($this->requestMethod) {
            case 'GET':
                if ($this->ma) {
                    $response = $this->getChuDe($this->ma);
                } else {
                    $response = $this->getAllChuDe();
                };
                break;
            case 'POST':
                $response = $this->createChuDe();
                break;
            case 'PUT':
                $response = $this->updateChuDe($this->ma);
                break;
            case 'DELETE':
                $response = $this->deleteChuDe($this->ma);
                break;
            default:
                $response = $this->notFoundResponse();
                break;
        }
        header($response['status_code_header']);
        if ($response['body']) {
            echo $response['body'];
        }
    }

    private function getAllChuDe()
    {
        $query = " SELECT MaChuDe, TenChuDe FROM ChuDe";
        try {
            $statement = $this->db->query($query);
            $result = $statement->fetchAll(\PDO::FETCH_ASSOC);
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }
        $response['status_code_header'] = 'HTTP/1.1 200 OK';
        $response['body'] = json_encode($result);
        return $response;
    }

    private function getChuDe($id)
    {
        $result = $this->find($id);
        if (! $result) {
            return $this->notFoundResponse();
        }
        $response['status_code_header'] = 'HTTP/1.1 200 OK';
        $response['body'] = json_encode($result);
        return $response;
    }

    private function createChuDe()
    {
        $input = (array) json_decode(file_get_contents('php://input'), TRUE);
        if (! $this->validateChuDe($input)) {
            return $this->unprocessableEntityResponse();
        }
        $query = "INSERT INTO ChuDe(MaChuDe, TenChuDe) VALUES(:ma, :tenCD)";
        try {
            $statement = $this->db->prepare($query);
            $statement->execute(array(
                'ma' => $input['maChuDe'], 'tenCD'  => $input['tenChuDe']));
            $statement->rowCount();
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }
        $response['status_code_header'] = 'HTTP/1.1 201 Created';
        $response['body'] = json_encode(array('message' => 'Post Created'));
        return $response;
    }

    private function updateChuDe($id)
    {
        $result = $this->find($id);
        if (! $result) {
            return $this->notFoundResponse();
        }
        $input = (array) json_decode(file_get_contents('php://input'), TRUE);
        if (! $this->validateChuDe($input)) {
            return $this->unprocessableEntityResponse();
        }

        $statement = "
      UPDATE ChuDe
      SET
        TenChuDe = :tenCD,
        MoTa  = :moTa
      WHERE MaChuDe = :ma;
    ";

        try {
            $statement = $this->db->prepare($statement);
            $statement->execute(array(
                'ma' => $id,
                'tenCD' => $input['tenChuDe'],
                'moTa'  => $input['moTa'],
                ));
            $statement->rowCount();
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }
        $response['status_code_header'] = 'HTTP/1.1 200 OK';
        $response['body'] = json_encode(array('message' => 'Post Updated!'));
        return $response;
    }

    private function deleteChuDe($id)
    {
        $result = $this->find($id);
        if (! $result) {
            return $this->notFoundResponse();
        }

        $query = "
      DELETE FROM ChuDe
      WHERE MaChuDe = :id;
    ";

        try {
            $statement = $this->db->prepare($query);
            $statement->execute(array('id' => $id));
            $statement->rowCount();
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }
        $response['status_code_header'] = 'HTTP/1.1 200 OK';
        $response['body'] = json_encode(array('message' => 'Post Deleted!'));
        return $response;
    }

    public function find($id)
    {
        $query = "SELECT MaChuDe, TenChuDe, MoTa FROM ChuDe WHERE MaChuDe = :id";

        try {
            $statement = $this->db->prepare($query);
            $statement->execute(array('id' => $id));
            $result = $statement->fetch(\PDO::FETCH_ASSOC);
            return $result;
        } catch (\PDOException $e) {
            exit($e->getMessage());
        }
    }

    private function validateChuDe($input)
    {
        if (! isset($input['maChuDe'])) {
            return false;
        }
        if (! isset($input['tenChuDe'])) {
            return false;
        }

        return true;
    }

    private function unprocessableEntityResponse()
    {
        $response['status_code_header'] = 'HTTP/1.1 422 Unprocessable Entity';
        $response['body'] = json_encode([
            'error' => 'Invalid input'
        ]);
        return $response;
    }

    private function notFoundResponse()
    {
        $response['status_code_header'] = 'HTTP/1.1 404 Not Found';
        $response['body'] = null;
        return $response;
    }
}