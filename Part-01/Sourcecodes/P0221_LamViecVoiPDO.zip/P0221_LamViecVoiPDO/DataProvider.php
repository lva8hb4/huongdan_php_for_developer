<?php


class DataProvider
{
    /**
     * Hàm thực hiện kết nối đến MySQL bằng PDO
     * @return Đối tượng kết nối
     */
     public function ketNoi()
     {
         $conn = null;

         try{
            //Kết nối đến db
             $conn = new PDO("mysql:localhost;port=3308;dbname=quanlynhanvien;charset=utf8mb4", "root", "Stanford");
             $conn->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
         }
         catch(PDOException $ex)
         {
             echo "Có lỗi xảy ra. Chi tiết: " . $ex->getMessage();
             die();
         }

         return $conn;
     }
}