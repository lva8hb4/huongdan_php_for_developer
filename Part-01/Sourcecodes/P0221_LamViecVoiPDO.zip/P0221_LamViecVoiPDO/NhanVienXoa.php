<?php
include_once 'NhanVienBusiness.php';
if(isset($_REQUEST['ma']))
{
    $maNV = $_REQUEST['ma'];

    $bus = new NhanVienBusiness();

    //Thuc hien xoa
    $ketQua = $bus->xoaNhanVien($maNV);

    if($ketQua > 0)
    {
        header("location:DanhSachNhanVien.php");
    }
    else
    {
        echo "Xoá nhân viên không thành công";
    }
}
?>