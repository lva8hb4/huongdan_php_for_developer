<?php

include_once 'DataProvider.php';
include_once 'NhanVien.php';
class NhanVienBusiness extends DataProvider
{

    /**
     * Hàm lấy danh sách nhân viên
     */
    public function layDanhSach()
    {
        //Khai báo 1 danh sách
        $lstNhanVien = Array();

        //Lấy kết nối
        $conn = $this->ketNoi();

        //Khai báo câu lệnh
        $sql = "Select MaNV, HoTen, DienThoai, Email, DiaChi from NhanVien";

        //Tạo câu lệnh
        $stm = $conn->prepare($sql);
        //Thiết lập chế độ lấy
        $stm->setFetchMode(PDO::FETCH_ASSOC);
        //Thực hiện công việc
        $stm->execute();

        //Lấy dữ liệu trả về
        $rows = $stm->fetchAll();

        $objNV = null;
        //Duyệt và in thông tin
        foreach($rows as $row)
        {
            //Khởi tạo đối tượng
            $objNV = new NhanVien();

            $objNV->MaNV = $row['MaNV'];
            $objNV->HoTen = $row['HoTen'];
            $objNV->DienThoai = $row['DienThoai'];
            $objNV->Email = $row['Email'];
            $objNV->DiaChi = $row['DiaChi'];

            //Đưa vào mảng
            array_push($lstNhanVien, $objNV);
        }

        //Đóng kết nối
        $conn = null;

        return $lstNhanVien;
    }

    public function layChiTietTheoMa($maNV)
    {
        //Lấy kết nối
        $conn = $this->ketNoi();

        //Khai báo câu lệnh
        $sql = "Select MaNV, HoTen, DienThoai, Email, DiaChi, MaPhong from NhanVien where MaNV = ?";

        //Tạo câu lệnh
        $stm = $conn->prepare($sql);
        $stm->bindValue(1, $maNV);

        //Thiết lập chế độ lấy
        $stm->setFetchMode(PDO::FETCH_CLASS, 'NhanVien');

        //Thực hiện công việc
        $stm->execute();

        //Lấy dữ liệu trả về
        $row = $stm->fetch();

        //Đóng kết nối
        $conn = null;

        return $row;
    }

    /**
     * Hàm thêm mới thông tin nhân viên
     * @param $objNV, Đối tượng nhân viên cần thêm mới
     */
    public function themMoi($objNV)
    {
        $conn = $this->ketNoi();

        //Câu lệnh thêm mới
        $insert = "Insert into NhanVien(MaNV, HoTen, DienThoai, Email, DiaChi, MaPhong) values(:ma, :ten, :dt, :mail, :dc, :)";

        //Khởi tạo prepare
        $stm = $conn->prepare($insert);
        $stm->bindParam(':ma', $objNV->MaNV);
        $stm->bindParam(':ten', $objNV->HoTen);
        $stm->bindParam(':dt', $objNV->DienThoai);
        $stm->bindParam(':mail', $objNV->Email);
        $stm->bindParam(':dc', $objNV->DiaChi);
        $stm->bindParam(':maPhong', $objNV->MaPhong);


        $ketQua = $stm->execute();

        //Đóng kết nối
        $conn = null;
        //Nếu số lượng lớn hơn 0 thì trả về true: Thành công
        if($stm->rowCount() > 0)
        {
            return true;
        }

        return false;
    }

    /**
     * Hàm cập nhật thông tin nhân viên
     * @param $objNV, Đối tượng nhân viên chứa thông tin cần cập nhật
     */
    public function capNhat($objNV)
    {
        $conn = $this->ketNoi();

        //Câu lệnh cập nhật
        $update = "Update NhanVien set HoTen=:HoTen, DienThoai=:DienThoai, Email=:Email, DiaChi=:DiaChi, GioiTinh=:GioiTinh, NgaySinh=:NgaySinh, MaPhong=:MaPhong where MaNV=:MaNV";

        //Khởi tạo prepare
        $stm = $conn->prepare($update);
        //print_r($objNV);
        $ketQua = $stm->execute((array)$objNV);

        //Đóng kết nối
        $conn = null;
        //Nếu số lượng lớn hơn 0 thì trả về true: Thành công
        if($stm->rowCount() > 0)
        {
            return true;
        }

        return false;
    }

    /**
     * Hàm xoá thông tin nhân viên
     * @param $maNV, Mã nhân viên cần xoá
     */
    public function xoaNhanVien($maNV)
    {
        $conn = $this->ketNoi();

        //Câu lệnh cập nhật
        $delete = "Delete from NhanVien where MaNV=:ma";

        //Khởi tạo prepare
        $stm = $conn->prepare($delete);

        $stm->bindParam(':ma', $maNV);

        $stm->execute();

        //Đóng kết nối
        $conn = null;

        //Nếu số lượng lớn hơn 0 thì trả về true: Thành công
        if($stm->rowCount() > 0)
        {
            return true;
        }

        return false;
    }
}