<?php
include_once 'NhanVienBusiness.php';
include_once 'PhongBanBusiness.php';
//Khai báo biến
$maNV=""; $hoTen = ""; $dienThoai = ""; $email = ""; $diaChi = "";
$maPhong = "";

$bus = new NhanVienBusiness();

//Lấy danh sách phòng ban
$phongBus = new PhongBanBusiness();

$phongBans = $phongBus->layDanhSach();

//TH sửa
if(isset($_REQUEST['ma']))
{
    $maNV = $_REQUEST['ma'];

    //Lấy thông tin chi tiết
    $objNV = $bus->layChiTietTheoMa($maNV);

    if($objNV != null)
    {
        $hoTen = $objNV->HoTen;
        $dienThoai = $objNV->DienThoai;
        $email = $objNV->Email;
        $diaChi = $objNV->DiaChi;
        $maPhong = $objNV->MaPhong;
    }
}
//Nếu mà nhấn nút Cập nhật
if(isset($_REQUEST['btnCapNhat']))
{
    //Lấy thông tin
    $maNV = $_POST['txtMaNV'];
    $id = $_POST['hMaNV'];
    $hoTen = $_POST['txtHoTen'];
    $dienThoai = $_POST['txtDienThoai'];
    $email = $_POST['txtEmail'];
    $diaChi = $_POST['txtDiaChi'];
    $maPhong = $_POST['cboPhong'];

    //Đưa vào đối tượng
    $objNV = new NhanVien();
    $objNV->MaNV = $maNV;
    $objNV->HoTen = $hoTen;
    $objNV->DienThoai = $dienThoai;
    $objNV->Email = $email;
    $objNV->DiaChi = $diaChi;
    $objNV->MaPhong = $maPhong;

    //TH sửa
    if(strlen($id) > 0){
        $bus->capNhat($objNV);
    }
    else {//TH thêm mới
        $bus->themMoi($objNV);
    }
}
?>
<html>
<head>
    <title>Thêm mới thông tin nhân viên</title>
</head>
<body>
<form method="post">
    <fieldset>
        <legend>Nhập thông tin nhân viên</legend>
        <table>
            <tr>
                <td>
                    Mã NV:
                </td>
                <td>
                    <input  type="text" name="txtMaNV" value="<?php echo $maNV?>"/>
                    <input type="hidden" name="hMaNV" value="<?php echo $maNV?>"/>
                </td>
            </tr>
            <tr>
                <td>
                    Họ tên:
                </td>
                <td>
                    <input  type="text" name="txtHoTen" value="<?php echo $hoTen?>"/>
                </td>
            </tr>
            <tr>
                <td>
                    Điện thoại:
                </td>
                <td>
                    <input  type="text" name="txtDienThoai" value="<?php echo $dienThoai ?>"/>
                </td>
            </tr>
            <tr>
                <td>
                    Email:
                </td>
                <td>
                    <input  type="text" name="txtEmail" value="<?php echo $email?>"/>
                </td>
            </tr>
            <tr>
                <td>
                    Địa chỉ:
                </td>
                <td>
                    <input type="text" name="txtDiaChi" value="<?php echo $diaChi ?>"/>
                </td>
            </tr>
            <tr>
                <td>Phòng:</td>
                <td>
                    <select name="cboPhong">
                        <option value="">---Chọn phòng---</option>
                        <?php foreach($phongBans as $phong){

                            if($maPhong == $phong->MaPhong){
                            ?>
                        <option selected="selected" value="<?echo $phong->MaPhong?>">
                            <?echo $phong->TenPhong?>
                        </option>
                                <?php
                            } else{
                                ?>
                                <option value="<?echo $phong->MaPhong?>">
                                    <?echo $phong->TenPhong?>
                                </option>
                        <?php
                       }
                        } ?>
                    </select>
                </td>
            </tr>
            <tr>
                <td>

                </td>
                <td>
                    <input type="submit" name="btnCapNhat" value="Cập nhật"/>
                    &nbsp;<a href="DanhSachNhanVien.php">Trở lại</a>
                </td>
            </tr>
        </table>
    </fieldset>
</form>
</body>
</html>
