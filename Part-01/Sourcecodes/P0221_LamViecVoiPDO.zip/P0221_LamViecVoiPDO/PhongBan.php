<?php


class PhongBan
{
    public $MaPhong;
    public $TenPhong;
    public $MoTa;
}