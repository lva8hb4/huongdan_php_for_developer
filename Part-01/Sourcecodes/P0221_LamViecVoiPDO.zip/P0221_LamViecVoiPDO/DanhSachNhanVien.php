<?php
include_once 'NhanVienBusiness.php';
include_once 'NhanVien.php';
//Khai báo đối tượng
$nhanVienBus = new NhanVienBusiness();

/*
//Thêm mới thông tin
$objNV = new NhanVien();
$objNV->maNV = "SF004";
$objNV->hoTen = "Vũ Thị Hoa";
$objNV->dienThoai = "0903456125";
$objNV->email = "hoavt@gmail.com";
$objNV->diaChi = "Hải Dương";

$nhanVienBus->themMoi($objNV);

echo "Cập nhật thông tin nv có mã SF004<br>";
$objNV = new NhanVien();
$objNV->MaNV = "SF004";
$objNV->HoTen = "Trần Thu Hoa";
$objNV->DienThoai = "090345126";
$objNV->Email = "thuhoa@gmail.com";
$objNV->DiaChi = "Hải Phòng";
$objNV->NgaySinh = date('Y-m-d');
$objNV->GioiTinh = 1;
$nhanVienBus->capNhat($objNV);*/

//$nhanVienBus->xoaNhanVien('SF004');

//Hiển thị danh sách
$danhSach = $nhanVienBus->layDanhSach();

//echo "Thông tin chi tiết nhân viên có mã : SF001<br>";
//$objNV = $nhanVienBus->layChiTietTheoMa('SF001');

//echo "Họ tên là: " . $objNV->MaNV;

?>
<html>
<head>
    <title>Danh sách thông tin nhân viên</title>
</head>
<body>
<div style="text-align:center; width:100%;">
    <h1>Danh sách thông tin nhân viên</h1>
</div>
<div style="text-align:right; width:100%;">
    <a href="NhanVienAdd.php" title="Nhấn vào để thêm mới nhân viên">Thêm mới</a>
</div>
<table border=1 style="width:100%; border-collapse:collapse;">
    <tr>
        <th>Mã NV</th>
        <th>Họ tên</th>
        <th>Điện thoại</th>
        <th>Email</th>
        <th>Địa chỉ</th>
        <th></th>
    </tr>
    <?php foreach($danhSach as $nv){?>
    <tr>
        <td><?php echo $nv->MaNV?></td>
        <td><?php echo $nv->HoTen?></td>
        <td><?php echo $nv->DienThoai?></td>
        <td><?php echo $nv
                ->Email?></td>
        <td><?php echo $nv->DiaChi?></td>
        <td>
            <a href="NhanVienAdd.php?ma=<?php echo $nv->MaNV?>">Sửa</a>
            &nbsp;
            <a onclick="return confirm('Bạn có chắc chắn muốn xoá nhân viên này ?');" href="NhanVienXoa.php?ma=<?php echo $nv->MaNV?>">Xoá</a>
        </td>
    </tr>
    <?php } ?>
</table>
</body>
</html>
