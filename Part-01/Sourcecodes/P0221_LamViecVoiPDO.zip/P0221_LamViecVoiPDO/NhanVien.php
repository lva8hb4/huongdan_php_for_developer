<?php


class NhanVien
{
    public $MaNV;
    public $HoTen;
    public $GioiTinh;
    public $NgaySinh;
    public $DienThoai;
    public $Email;
    public $DiaChi;
    public $MaPhong;

}