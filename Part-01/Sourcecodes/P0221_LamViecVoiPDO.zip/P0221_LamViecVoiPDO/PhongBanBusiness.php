<?php

include_once 'DataProvider.php';
include_once 'PhongBan.php';
class PhongBanBusiness extends DataProvider
{
    /**
     * Hàm lấy danh sách phòng ban
     */
    public function layDanhSach()
    {
        //Khai báo 1 danh sách
        $lstPhong = Array();

        //Lấy kết nối
        $conn = $this->ketNoi();

        //Khai báo câu lệnh
        $sql = "Select MaPhong, TenPhong, MoTa from PhongBan";

        //Tạo câu lệnh
        $stm = $conn->prepare($sql);
        //Thiết lập chế độ lấy
        $stm->setFetchMode(PDO::FETCH_ASSOC);
        //Thực hiện công việc
        $stm->execute();

        //Lấy dữ liệu trả về
        $rows = $stm->fetchAll();

        $objPhong = null;
        //Duyệt và in thông tin
        foreach($rows as $row)
        {
            //Khởi tạo đối tượng
            $objPhong = new PhongBan();

            $objPhong->MaPhong = $row['MaPhong'];
            $objPhong->TenPhong = $row['TenPhong'];
            $objPhong->MoTa = $row['MoTa'];

            //Đưa vào mảng
            array_push($lstPhong, $objPhong);
        }

        //Đóng kết nối
        $conn = null;

        return $lstPhong;
    }
}